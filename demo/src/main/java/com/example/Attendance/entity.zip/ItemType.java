package com.example.Attendance.entity;

public enum ItemType {
	EQUIP,
	CONSUMABLE,
	DECOR

}
