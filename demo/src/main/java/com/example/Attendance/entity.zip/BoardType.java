package com.example.Attendance.entity;

public enum BoardType {
    FREE, NOTICE, SUGGEST
}